const getSimpleStatisticsFromUnpkg = async () =>{ await import("https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js");
await import("https://d3js.org/d3.v7.min.js"); await import("https://cdn.anychart.com/releases/8.8.0/js/anychart-base.min.js");};

const getpackages= getSimpleStatisticsFromUnpkg();
let kin = document.querySelector("#sku-list").children;

// Loop through each product in the table
for (let i = 0; i < kin.length; i++) {
  let link = kin[i].getElementsByClassName("js-sku-link")[2].href.replace(/.html.*/,'/price_graph.json');

  // Load the data for the product
  fetch(link)
    .then(response => response.json())
    .then(data => {
      // Extract the data for each time period
      const timePeriods = Object.keys(data['min_price']['graphData']);
      const boxPlotData = [];
      timePeriods.forEach(period => {
        const values = data['min_price']['graphData'][period]['values'];
        const prices = values.map(v => v['value']).filter(p => p !== 0.0);
        boxPlotData.push({
          min: d3.min(prices),
          q1: d3.quantile(prices, 0.25),
          median: d3.median(prices),
          q3: d3.quantile(prices, 0.75),
          max: d3.max(prices)
        });
      });
      console.log(boxPlotData);
      // Create a new element to hold the box plots
      const ctx = document.createElement('div');
      //g = document.createElement('div');
      ctx.setAttribute("id", "container");
      ctx.className='grafima';
      kin[i].appendChild(ctx);
      /*chart = anychart.box();
      series = chart.box(boxPlotData);
      // set the container id
      chart.container('container');
      // Insert the box plots into the element
      // initiate drawing the chart
      chart.draw();
      */
      // Set the dimensions and margins of the chart
parentElement=kin[i]
const margin = { top: 20, right: 20, bottom: 30, left: 40 },
width = parentElement.offsetWidth - margin.left - margin.right,
height = parentElement.offsetHeight - margin.top - margin.bottom;

// Append the svg object to the body of the page
const svg = d3.select(parentElement)
.append('svg')
  .attr('width', width + margin.left + margin.right)
  .attr('height', height + margin.top + margin.bottom)
.append('g')
  .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');

// Set the ranges
const x = d3.scaleBand()
.range([0, width])
.padding(0.1);
const y = d3.scaleLinear()
.range([height, 0]);

// Scale the range of the data in the domains
x.domain(boxPlotData.map(function(d) { return d.label; }));
y.domain([0, d3.max(boxPlotData, function(d) { return d.max; })]);

// Add the X Axis
svg.append('g')
.attr('transform', 'translate(0,' + height + ')')
.call(d3.axisBottom(x));

// Add the Y Axis
svg.append('g')
.call(d3.axisLeft(y));

// Add the main box plot elements
const boxPlot = svg.selectAll('.box')
.data(boxPlotData)
.enter().append('g')
  .attr('transform', function(d) { return 'translate(' + x(d.label) + ',0)'; });

// Add the whiskers
boxPlot.append('line')
.attr('x1', 0)
.attr('y1', function(d) { return y(d.max); })
.attr('x2', 0)
.attr('y2', function(d) { return y(d.min); })
.attr('stroke', '#000')
.attr('stroke-width', 1);

// Add the lower whisker
boxPlot.append('line')
.attr('x1', -10)
.attr('y1', function(d) { return y(d.q1); })
.attr('x2', 10)
.attr('y2', function(d) { return y(d.q1); })
.attr('stroke', '#000')
.attr('stroke-width', 1);

// Add the upper whisker
boxPlot.append('line')
.attr('x1', -10)
.attr('y1', function(d) { return y(d.q3); })
.attr('x2', 10)
.attr('y2', function(d) { return y(d.q3); })
.attr('stroke', '#000')
.attr('stroke-width', 1);

// Add the rectangles for the main body of the box plot
boxPlot.append('rect')
.attr('x', -10)
.attr('y', function(d) { return y(d.q3); })
.attr('height', function(d) { return y(d.q1) - y(d.q3); })
.attr('width', 20)
.attr('fill', '#69b3a2');

// Add the median line
boxPlot.append('line')
.attr('x1', -10)
.attr('y1', function(d) { return y(d.median); })
.attr('x2', 10)
.attr('y2', function(d) { return y(d.median); })
.attr('stroke', '#000')
.attr('stroke-width', 2);



      // Add the element to the DOM
      
    })
};
